import express from "express";

const router = express.Router();

import UsersController from "../controllers/UsersController";

router.get('/', UsersController.myAccount);
router.post('/register', UsersController.register);
router.post('/userConfirm', UsersController.userVerification);
router.post('/login', UsersController.login);
router.put('/', UsersController.update);
router.delete('/', UsersController.delete);

export default router;
