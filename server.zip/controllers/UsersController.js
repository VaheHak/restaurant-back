import HttpError from 'http-errors';
import jwt from 'jsonwebtoken';
import {Users} from '../models';
import {v4 as uuidv4} from 'uuid';
import transporter from '../middlewares/nodemailer';
import Validate from "../config/validate";

const {JWT_SECRET, VERIFICATION_URL} = process.env;

class UsersController {
    static myAccount = async (req, res, next) => {
        try {
            const result = await Users.findByPk(req.userId);
            res.json({
                result,
            });
        } catch (e) {
            next(e);
        }
    }

    static register = async (req, res, next) => {
        try {
            await Validate(req.body, {
                firstName: 'string|required|alpha|minLength:2|maxLength:20',
                lastName: 'string|required|alpha|minLength:3|maxLength:20',
                phone: 'required|minLength:3|maxLength:20',
                restId: 'integer',
                roleId: 'required|integer|min:2|max:3',
                email: 'required|email',
                password: 'required|minLength:4|maxLength:20',
            })
            const {firstName, lastName, phone, restId, roleId, email, password} = req.body
            const activation_code = uuidv4();
            const status = 'pending';
            const user = await Users.create({
                firstName,
                lastName,
                phone,
                restId,
                roleId,
                activation_code,
                status,
                email,
                password,
            });
            let confInfo = `
                <div style="width: 100%;height:300px;display: flex;justify-content: center;align-items: center">
                    <a style="width: 150px;height: 30px;background: green;font-weight: bold;
                    display: flex;justify-content: center;align-items: center;color:black"
                     href="${VERIFICATION_URL + activation_code}">CONFIRM</a>
                </div>
            `
            const info = await transporter.sendMail({
                from: '"QR Restaurant" <qrrestaurant@mail.ru>',
                to: email,
                subject: "Verification",
                text: "Hello " + firstName + lastName,
                html: confInfo,
            });
            res.json({
                status: 'ok',
                user,
                info,
            });
        } catch (e) {
            next(e);
        }
    }
    static userVerification = async (req, res, next) => {
        try {
            await Validate(req.body, {
                activation_code: 'required',
            })
            const {activation_code} = req.body
            const user = await Users.findOne({
                where: {
                    activation_code
                }
            });
            const status = 'activated';
            if (user) {
                const result = await Users.update({
                    status
                }, {
                    where: {
                        id: user.id,
                    }
                });
                res.json({
                    status: 'Activated',
                    result,
                });
            } else {
                res.json({
                    result: "No such user. Try to register again."
                })
            }
        } catch (e) {
            next(e);
        }
    }

    static login = async (req, res, next) => {
        try {
            await Validate(req.body, {
                email: 'required|email',
                password: 'required'
            })
            const {email, password} = req.body;
            const result = await Users.findOne({
                where: {
                    email: email,
                },
            });

            if (!result || result.getDataValue('password') !== Users.passwordHash(password)) {
                throw HttpError(403, 'invalid email or password');
            }

            const token = jwt.sign({userId: result.id}, JWT_SECRET);

            res.json({
                status: 'ok',
                result,
                token,
            });
        } catch (e) {
            next(e);
        }
    }

    static update = async (req, res, next) => {
        try {
            const {id, firstName, lastName, email, password,} = req.body;
            const result = await Users.update({
                firstName, lastName, email, password,
            }, {
                where: {
                    id,
                }
            });
            res.json({
                status: 'Updated',
                result,
            });
        } catch (e) {
            next(e)
        }
    }

    static delete = async (req, res, next) => {
        try {
            const {id} = req.body;
            const result = await Users.destroy({
                where: {
                    id,
                }
            });

            res.json({
                status: 'Deleted',
                result,
            });
        } catch (e) {
            next(e)
        }
    }
}

export default UsersController;
